using System;

public class DCT
{
    public static String PREFIX = "http://purl.org/dc/terms/";

    public static String title = PREFIX + "title";

    // public static IRI createIRI(String fragment)
    // {
    //     return SimpleValueFactory.getInstance().createIRI(PREFIX + fragment);
    // }

    DCT() { }
}
