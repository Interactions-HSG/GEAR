using System;

public class COV
{
    public static String PREFIX = "http://www.example.org/coap-binding#";

    public static String methodName = PREFIX + "methodName";
    public static String observe = PREFIX + "observe";

    // public static IRI createIRI(String fragment)
    // {
    //     return SimpleValueFactory.getInstance().createIRI(PREFIX + fragment);
    // }

    COV() { }
}
