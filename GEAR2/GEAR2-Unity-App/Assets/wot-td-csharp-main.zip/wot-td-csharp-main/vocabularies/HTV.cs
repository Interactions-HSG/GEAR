using System;

public class HTV
{
    public static String PREFIX = "http://www.w3.org/2011/http#";

    public static String methodName = PREFIX + "methodName";

    // public static IRI createIRI(String fragment) {
    //   return SimpleValueFactory.getInstance().createIRI(PREFIX + fragment);
    // }

    HTV() { }
}
